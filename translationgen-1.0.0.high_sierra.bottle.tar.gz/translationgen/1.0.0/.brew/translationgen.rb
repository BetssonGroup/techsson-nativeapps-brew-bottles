class Translationgen < Formula
  desc "Translation Generator for OBG wrapper apps"
  homepage "https://bitbucketsson.betsson.local/projects/OBGNTR/repos/translationgen/browse"
  url "https://bitbucketsson.betsson.local/scm/obgntr/translationgen.git", :using => :git, :tag => "1.0.0"
  version "1.0.0"

  depends_on :xcode => ["9.4.1", :build]
  depends_on "cocoapods"

  def install
    system "make", "install", "PREFIX=#{prefix}"
  end

  test do
    # `test do` will create, run in and delete a temporary directory.
    #
    # This test will fail and we won't accept that! It's enough to just replace
    # "false" with the main program this formula installs, but it'd be nice if you
    # were more thorough. Run the test with `brew test contentgen?at=refs%2Fheads%2Frelease%2F`. Options passed
    # to `brew install` such as `--HEAD` also need to be provided to `brew test`.
    #
    # The installed folder is not in the path, so use the entire path to any
    # executables being tested: `system "#{bin}/program", "do", "something"`.
    system "false"
  end
end
