## What's this?
TranslationGen is an OSX command line tool responsible for creating translation files for the iOS and Android OBG apps.

## Installation
Tap the OBG formula repository
```
brew tap obg/formulae ssh://git@bitbucketsson.betsson.local:7999/obgntr/brew-formulae.git
```

Install TranslationGen
```
brew install translationgen
```

## Updating
```
brew update
brew upgrade translationgen
```

## Usage
Type `translationgen` into terminal to get a list of supported parameters.

## Troubleshooting
Brew doesn't detect the latest version.
> Try `brew update` a second time. If that doesn't help, then un-tap then re-tap the obg/formulae repository.
>
> ```brew untap obg/formulae```
>
> ```brew tap obg/formulae ssh://git@bitbucketsson.betsson.local:7999/obgntr/brew-formulae.git```
